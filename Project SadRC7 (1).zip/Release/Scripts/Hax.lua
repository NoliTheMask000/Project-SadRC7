print("Thanks for using Protosmasher remake by Hizzo")
